"""Training and evaluation engines."""
