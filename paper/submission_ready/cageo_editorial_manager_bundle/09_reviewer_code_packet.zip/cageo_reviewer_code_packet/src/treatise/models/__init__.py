"""Model zoo for Treatise."""
