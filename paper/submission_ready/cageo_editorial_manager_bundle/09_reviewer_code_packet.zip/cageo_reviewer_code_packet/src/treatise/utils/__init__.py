"""Shared utilities for Treatise."""
