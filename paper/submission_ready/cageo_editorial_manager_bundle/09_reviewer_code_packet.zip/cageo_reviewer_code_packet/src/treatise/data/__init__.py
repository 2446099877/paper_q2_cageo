"""Data utilities for Treatise."""
