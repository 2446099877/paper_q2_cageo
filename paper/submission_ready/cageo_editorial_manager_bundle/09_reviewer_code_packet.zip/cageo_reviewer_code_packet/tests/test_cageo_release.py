from __future__ import annotations

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class CageoReleaseTests(unittest.TestCase):
    def test_license_exists(self) -> None:
        self.assertTrue((ROOT / "LICENSE").exists())

    def test_reviewer_packet_script_exists(self) -> None:
        self.assertTrue((ROOT / "scripts" / "prepare_cageo_reviewer_code_packet.py").exists())

    def test_submission_packet_notes_exist(self) -> None:
        notes_dir = ROOT / "docs" / "submission_packets"
        required = [
            "cageo_authorship_statement.md",
            "cageo_cover_letter_draft.md",
            "cageo_highlights_draft.md",
            "cageo_official_notes_2026-03-22.md",
            "cageo_pre_submission_checklist.md",
            "cageo_status.md",
        ]
        missing = [name for name in required if not (notes_dir / name).exists()]
        self.assertEqual(missing, [], msg=f"Missing packet notes: {missing}")

    def test_submission_pdf_exists(self) -> None:
        self.assertTrue((ROOT / "paper" / "submission_ready" / "cageo" / "manuscript.pdf").exists())


if __name__ == "__main__":
    unittest.main()
