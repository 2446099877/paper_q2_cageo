# Q2 C&G Workspace

这个目录是新论文的独立总工作区。

## 目标

- 目标期刊：`Computers & Geosciences`
- 目标档位：`中科院二区`
- 工作原则：
  - 新论文的文稿、脚本、配置、结果快照、后续新增训练输出，都只放在这个目录下
  - 旧论文继续保留在仓库原有目录，不和这里混用

## 当前结构

- `docs/`: 新论文的选刊、执行计划、投稿材料说明
- `paper/`: 新论文的 LaTeX 稿、图表、模板和提交包
- `scripts/`: 新论文专用的构建、打包、训练和聚合脚本
- `configs/`: 新论文专用配置
- `src/`: 复制出的代码依赖，保证后续新训练可以在这个工作区里独立进行
- `data/splits/`: 新论文使用的 split 清单
- `outputs/`: 新论文的结果快照与后续新增训练输出

## 数据策略

- 原始公开数据仍复用仓库上层的共享数据目录：
  - `../data/raw/AID`
  - `../data/raw/NWPU_RESISC45`
- 这样避免重复拷贝大数据，同时保证新论文所有训练结果都写入本目录自己的 `outputs/`

## 常用命令

- 重建并编译 `C&G` 提交包：
  - `D:\python311\python.exe D:\codex\treatise\paper_q2_cageo\scripts\compile_cageo_pdf.py`
- 检查提交包占位符：
  - `D:\python311\python.exe D:\codex\treatise\paper_q2_cageo\scripts\check_cageo_packet_readiness.py`
- 生成 `C&G` reviewer-safe 代码包：
  - `D:\python311\python.exe D:\codex\treatise\paper_q2_cageo\scripts\prepare_cageo_reviewer_code_packet.py`

## 说明

- `outputs/` 里当前先放的是从旧主线导入的最小结果快照，用于复现表格，不是旧论文的完整训练仓
- 如果后续需要继续补新实验，直接让新训练输出落到这里的 `outputs/` 即可
- 当前默认开源许可已准备为：
  - `MIT`，见 [LICENSE](/D:/codex/treatise/paper_q2_cageo/LICENSE)
