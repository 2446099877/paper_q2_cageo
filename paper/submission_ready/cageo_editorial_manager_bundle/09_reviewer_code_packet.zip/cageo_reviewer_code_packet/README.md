# C&G Reviewer Code Packet

This packet provides the minimal code and documentation needed to inspect and reproduce the current `Computers & Geosciences` manuscript workflow without bundling large raw datasets or heavy outputs.

## Included

- `configs/`: experiment configurations
- `scripts/`: training, evaluation, aggregation, and manuscript-build scripts
- `src/`: project source code
- `tests/`: lightweight integrity checks for the C&G workspace
- `docs/`: protocol, results snapshot, reviewer quickstart, and reviewer risk notes
- `paper/generated_lowshot/`: LaTeX tables used by the manuscript
- `LICENSE`: default open-source license prepared for the final public release

## Not Included

- `data/raw/`: public datasets must be downloaded separately
- `outputs/`: heavy checkpoints and logs are intentionally excluded
- final public repository URL: to be filled once the online repository is created

## Quickstart

1. Install dependencies with `D:\python311\python.exe -m pip install -r requirements.txt`
2. Prepare public datasets under:
   - `data/raw/AID/<class_name>/*.jpg`
   - `data/raw/NWPU_RESISC45/<class_name>/*.jpg`
3. Read `docs/experiment_protocol.md`
4. Use `docs/reviewer_reproduction_quickstart.md` as the shortest reproduction path
